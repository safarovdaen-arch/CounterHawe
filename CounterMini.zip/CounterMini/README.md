# Counter Mini (APK через GitHub Actions)
Игра: www/index.html (three.js подтягивается из npm и кладётся в www при сборке, работает без интернета).
Сборка: Capacitor 5 -> debug APK (app-debug.apk), ставится на любой Android.
